# Moxie × Axen landing page (GitHub Pages + iframe)

## What's in this folder
- `index.html`: the page (about 58 KB)
- `assets/`: logos, the Scotsman Guide badge, the Google logo and the Moxie M
- `EMBED-ON-MOXIEMORTGAGE.html`: the snippet to paste into moxiemortgage.com/axen

## 1. Publish on GitHub Pages
jsDelivr and raw.githubusercontent.com serve HTML as plain text, so the page won't render in an iframe from either one. It has to be served by **GitHub Pages**.

Suggested setup, using your existing public repo:
1. Copy this folder into `rlucido15/moxie-email-assets` as `/axen/` (so the path is `/axen/index.html` with `/axen/assets/`).
2. In the repo, go to **Settings → Pages → Build and deployment**, choose **Deploy from a branch**, then branch `main`, folder `/ (root)`, and click Save.
3. After a minute or two the page is live at **https://rlucido15.github.io/moxie-email-assets/axen/**.

Your existing jsDelivr image links keep working.

## 2. Embed on moxiemortgage.com/axen
Paste the whole of `EMBED-ON-MOXIEMORTGAGE.html` into an HTML / custom-code block. If you published somewhere other than the address above, change `PAGE_URL` first.

The snippet:
- resizes the frame to fit the page, with no inner scrollbar
- passes `?agent=` and `utm_` tags from the moxiemortgage.com address into the page, so leads keep their source, and records the parent page URL
- shows the "Claim your credit" form in the middle of what the visitor is looking at, and locks scrolling behind it
- opens the application (and phone links) in the full window; it only accepts apply.moxiemortgage.com and tel: links from the frame

The mobile sticky "Claim your credit" bar is turned off inside the iframe, because a framed page can't pin a bar to the visitor's screen.

## 3. Settings inside index.html
`MXA_CONFIG` near the bottom of `index.html`:
- `phone`: office number (still blank)
- `reviewsEndpoint`: your Google reviews Apps Script URL (still blank)
- `leadEndpoint`: already set to the Lofty lead intake

Lead tags: "CTA: Axen Credit" (every Claim your credit button) and "CTA: Call Request - Axen" (the call-request form).

## SEO note
Search engines credit text inside an iframe to the GitHub page, not to moxiemortgage.com. The GitHub page is marked `noindex` so it won't compete with your site. Give the moxiemortgage.com/axen page its own title and meta description in your site builder.
